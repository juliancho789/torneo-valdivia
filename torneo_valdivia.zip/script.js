// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyDK6IT8Xspx1JkykwXGoJvt69baq2XJ0yU",
  authDomain: "torneo-valdivia.firebaseapp.com",
  projectId: "torneo-valdivia",
  storageBucket: "torneo-valdivia.appspot.com",
  messagingSenderId: "76501433589",
  appId: "1:76501433589:web:9e4febdbb445f295a699bc",
  measurementId: "G-STBC37NNG8"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();

document.getElementById("formEquipo").addEventListener("submit", e=>{
  e.preventDefault();
  const nombre = document.getElementById("nombreEquipo").value.trim();
  const logoInput = document.getElementById("logoEquipo").files[0];
  if(!nombre) return alert("Nombre vacío");
  const reader = new FileReader();
  reader.onload = function(evt){
    db.collection("equipos").add({nombre, logo: evt.target.result}).then(render);
  };
  reader.readAsDataURL(logoInput);
  e.target.reset();
});

function render() {
  db.collection("equipos").get().then(snapshot=>{
    const lista = document.getElementById("listaEquipos");
    lista.innerHTML = '';
    snapshot.forEach((doc)=>{
      const data = doc.data();
      const li = document.createElement('li');
      li.innerHTML = `<img src="${data.logo}" class="equipo-logo"> ${data.nombre}`;
      lista.appendChild(li);
    });
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  render();
});